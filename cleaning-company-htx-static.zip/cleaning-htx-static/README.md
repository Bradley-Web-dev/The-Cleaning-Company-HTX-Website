# The Cleaning Company HTX — Static Website

A complete, dependency-free static website for **The Cleaning Company HTX
LLC**, a residential cleaning company in Houston, TX. Pure HTML5, CSS3, and
vanilla JavaScript — no framework, no build step, no backend, no API keys.

---

## 1. File structure

```
/
├── index.html          Everything: all sections, structured data, meta tags
├── styles.css           All styles (CSS custom properties for the design tokens)
├── script.js             All behavior (config at the top — see § 3)
├── assets/
│   ├── favicon.svg
│   ├── hero.jpg               ⚠ placeholder — see § 4
│   ├── service-cleaning.jpg   ⚠ placeholder (Recurring Cleaning)
│   ├── deep-cleaning.jpg      ⚠ placeholder
│   ├── move-in.jpg            ⚠ placeholder
│   ├── move-out.jpg           ⚠ placeholder
│   ├── airbnb.jpg             ⚠ placeholder
│   └── organizing.jpg         ⚠ placeholder
└── README.md
```

No `node_modules`, no package.json, nothing to install. Open `index.html`
directly in a browser, or serve the folder with any static file server.

---

## 2. Deploying

Because this is 100% static, you can drag-and-drop the whole folder onto
any of these and it will work immediately:

- **Netlify** — drag the folder into the Netlify dashboard, or connect a
  GitHub repo and set the publish directory to the project root.
- **Vercel** — `vercel deploy` from inside the folder, or import via
  GitHub with no build command / no output directory overrides needed.
- **GitHub Pages** — push to a repo, then enable Pages on the `main`
  branch (root folder).
- **Cloudflare Pages** — connect the repo with build command "none" and
  output directory "/".

There is nothing to configure beyond what's described below — no
environment variables, no server, no functions.

---

## 3. Where to paste your Google URLs (already done for you)

Right at the top of **`script.js`**:

```js
const BUSINESS_PHONE = "+18322898920";
const BUSINESS_PHONE_DISPLAY = "+1 832-289-8920";
const GOOGLE_REVIEWS_URL = "https://www.google.com/maps/place/The+Cleaning+Company+HTX+LLC/...";
const GOOGLE_MAPS_URL = "https://www.google.com/maps/dir/?api=1&destination=1095+Brittmoore+Rd%2C+Houston%2C+TX+77043";
```

- **`GOOGLE_REVIEWS_URL`** is set to the exact Google Maps listing URL you
  provided. Every "Read All Google Reviews" / "See What Our Customers Say
  on Google" button on the site uses this constant automatically (the
  page finds every element with a `data-google-reviews-link` attribute on
  load and points it here) — you don't need to touch the HTML.
- **`GOOGLE_MAPS_URL`** is a directions link built from the business
  address using Google's key-free Maps URL scheme, since a dedicated
  directions link works better for a "Get Directions" button than the
  reviews-listing URL. Swap it for any other Maps link if you'd prefer —
  it's the only place that needs to change.

To reuse this template for a different business later, changing those
four constants (plus the address in the structured data — see § 6) is
everything you need to touch.

---

## 4. Placeholder images

Every file in `assets/` is a generated placeholder — a labeled graphic in
the site's own color palette, not a real photo, and not a stock photo
pretending to be your work. Replace each one with a real photo at the
same filename and it'll drop right in (recommended sizes below):

| File | Used for | Suggested size |
|---|---|---|
| `hero.jpg` | Hero section | ~1000×1250 (4:5 portrait) |
| `service-cleaning.jpg` | Recurring Cleaning card | ~800×600 (4:3) |
| `deep-cleaning.jpg` | Deep Cleaning card | ~800×600 |
| `move-in.jpg` | Move-In Cleaning card | ~800×600 |
| `move-out.jpg` | Move-Out Cleaning card | ~800×600 |
| `airbnb.jpg` | Airbnb Cleaning card | ~800×600 |
| `organizing.jpg` | Home Organizing card | ~800×600 |

No HTML/CSS changes are needed — the layout uses `object-fit: cover`, so
any reasonably-sized photo in roughly the same aspect ratio will look
right.

---

## 5. The quote form — how it actually works (no backend)

Per the requirements, this form does **not** pretend to email anyone —
there's no email address anywhere on the site, and no server to send
one from. Instead, on submit it:

1. Validates the required fields (Name, Phone, Service) with plain
   JavaScript — no page reload.
2. Builds a plain-text summary of everything entered.
3. Shows a success panel with two real actions:
   - **"Text Us This Request"** — opens the visitor's own messaging app
     via an `sms:` link, pre-filled with the summary, addressed to
     +1 832-289-8920.
   - **"Call Now"** — a `tel:` link to the same number.

This means every submission genuinely reaches you — just via the
visitor's phone, not a server. Nothing is silently lost, and nothing
falsely claims to have been emailed.

**If you'd like the form to also land somewhere automatically** (e.g., a
spreadsheet or inbox) without running your own backend, this is a one-
attribute change with any of these static-friendly services — none
require a server, database, or API key of your own:

- **Netlify Forms** (if hosting on Netlify) — add `data-netlify="true"`
  and a hidden `<input type="hidden" name="form-name" value="quote">` to
  the `<form id="quoteForm">` in `index.html`. Netlify then captures
  submissions in your site dashboard automatically.
- **Formspree** or **Getform** — sign up, then set the form's `action` to
  the endpoint they give you and let it submit normally (you'd remove or
  adjust the `event.preventDefault()` in `script.js` → `initQuoteForm()`
  accordingly, or POST via `fetch()` in the background and keep showing
  the current success panel).

The relevant spot is marked with a comment directly above the
`<form id="quoteForm">` tag in `index.html`.

---

## 6. SEO / structured data

`index.html` includes, all pre-filled with your real business info:

- Title, meta description, canonical link (placeholder domain — see
  below), Open Graph tags, and a Twitter/X card
- `LocalBusiness` structured data with your real address, phone, and
  Google rating (5.0 / 32 reviews), linked to your actual Google Maps
  listing via `sameAs`
- One `Service` entry per offering (Recurring, Deep, Move-In, Move-Out,
  Airbnb Cleaning)
- `FAQPage` structured data mirroring the visible FAQ section

**One placeholder to update once you have a domain:** search
`index.html` for `REPLACE-WITH-YOUR-DOMAIN.com` (it appears in the
canonical link, Open Graph tags, and the structured data `@id`/`url`
fields) and replace it with your real domain, or your GitHub
Pages/Netlify/Vercel URL if you're not using a custom domain yet.

---

## 7. What's been checked

- **Structure** — every HTML tag validated for correct nesting/closure;
  every CSS class used in the markup has a matching rule; every
  `getElementById` / `data-*` / class selector referenced in `script.js`
  matches something real in `index.html`
- **No email anywhere** — confirmed no email address, `mailto:` link, or
  email form field exists on the page
- **No backend / no API** — confirmed no `fetch()`/`XMLHttpRequest` calls,
  no API keys, nothing that requires a server to function
- **Phone links** — every phone number is a real `tel:+18322898920` link
- **Google Reviews buttons** — all four (hero trust indicator is text-
  only; header, reviews section, contact section, footer, and mobile bar
  are real links) point to your provided Google Maps URL via the shared
  config constant
- **Quote form** — required-field validation, SMS/Call success actions,
  and service-card "Request a Quote" links that preselect the right
  service in the form
- **FAQ accordion** — keyboard-operable, proper `aria-expanded`/
  `aria-controls`/`role="region"` wiring
- **Mobile** — sticky bottom bar (Call / Quote / Reviews), responsive
  layout from ~360px up, safe-area padding for iOS home indicators
- **Accessibility** — semantic landmarks, skip-to-content link, labeled
  form fields, visible focus states, alt text on every image, and a
  darker gold tone for star ratings specifically chosen for better
  contrast against the light background
- **No invented facts** — every claim, guarantee, and statistic on the
  page traces back to information actually provided; no fake reviews,
  awards, certifications, or pricing anywhere

What I *couldn't* do: render this in an actual browser to visually confirm
it (no browser available in this environment). I validated it a different
way instead — parsing the HTML for correct tag nesting, running the JS
through Node's syntax checker, and cross-referencing every ID/class/data-
attribute between the three files by script rather than by eye. Please
open `index.html` locally as your first step, and let me know if anything
looks off — happy to fix it right away.
